module configs
    config = bsoc.config


function(fpsoptimized){
    delete.object(humanoid.texture.HITBOX)
    restore.object(match.variable = false)
}

function(fpsoptimized)

exit